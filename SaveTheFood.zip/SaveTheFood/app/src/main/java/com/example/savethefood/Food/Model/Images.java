package com.example.savethefood.Food.Model;

import com.google.gson.annotations.SerializedName;

public class Images {
    @SerializedName("front")
    private ImageFont imageFonts;

    public ImageFont getImageFonts() {
        return imageFonts;
    }
}
